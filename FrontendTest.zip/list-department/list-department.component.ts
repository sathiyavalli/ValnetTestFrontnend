import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-department',
  templateUrl: './list-department.component.html',
  styleUrls: ['./list-department.component.css']
})
export class ListDepartmentComponent implements OnInit {
searchText
  constructor() { }

  ngOnInit(): void {
  }
  details = [
  { id: 1, name: 'Cardiiology'},
  { id: 2, name: 'Oncology' },
  { id: 3, name: 'Gynaecology' },
];
}
