import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 11, name: 'Project 1' },
  { id: 12, name: 'Project 2' },
  { id: 13, name: 'Project 3' },
  { id: 14, name: 'Project 4' },
  { id: 15, name: 'Project 5' },
  { id: 16, name: 'Project 6' },
  { id: 17, name: 'Project 7' },
  { id: 18, name: 'Project 8' },
  { id: 19, name: 'Project 9' },
  { id: 20, name: 'Project 10' }
];
localStorage.setItem('heroes', JSON.stringify(HEROES));
